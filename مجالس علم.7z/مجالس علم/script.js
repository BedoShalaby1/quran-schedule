// جدول المواعيد
const lessons = [
    { day: 2, hour: 22, name: "مجلس حفظ (الثلاثاء 10 مساءً)" }, // الثلاثاء
    { day: 4, hour: 20, name: "مراجعة جماعية (الخميس 8 مساءً)" } // الخميس
];

// دالة التحقق من الإشعارات
function checkNotifications() {
    if (!("Notification" in window)) {
        document.getElementById('status').textContent = "المتصفح لا يدعم الإشعارات";
        return;
    }

    if (Notification.permission === "granted") {
        document.getElementById('status').textContent = "الإشعارات مفعلة ✓";
        document.getElementById('enable-btn').style.display = "none";
        startNotificationCheck();
    } else {
        document.getElementById('status').textContent = "الإشعارات غير مفعلة";
        document.getElementById('enable-btn').style.display = "block";
    }
}

// تفعيل الإشعارات
document.getElementById('enable-btn').addEventListener('click', () => {
    Notification.requestPermission().then(permission => {
        if (permission === "granted") {
            document.getElementById('status').textContent = "الإشعارات مفعلة ✓";
            document.getElementById('enable-btn').style.display = "none";
            startNotificationCheck();
        } else {
            document.getElementById('status').textContent = "تم رفض الإشعارات";
        }
    });
});

// التحقق من المواعيد
function startNotificationCheck() {
    checkForUpcomingLessons();
    setInterval(checkForUpcomingLessons, 5 * 60 * 1000); // التحقق كل 5 دقائق
}

function checkForUpcomingLessons() {
    const now = new Date();
    const currentDay = now.getDay(); // 0 لأحد، 1 لاثنين...
    const currentHour = now.getHours();
    const currentMinutes = now.getMinutes();

    lessons.forEach(lesson => {
        if (lesson.day === currentDay) {
            // قبل الموعد بنصف ساعة بالضبط
            if (currentHour === lesson.hour - 1 && currentMinutes === 30) {
                showNotification(lesson.name);
            }
        }
    });
}

function showNotification(lessonName) {
    if (Notification.permission === "granted") {
        new Notification("تذكير بالمجلس القرآني", {
            body: `بقى نصف ساعة على موعد ${lessonName}`,
            icon: "https://cdn-icons-png.flaticon.com/512/2821/2821807.png",
            vibrate: [200, 100, 200] // اهتزاز للأجهزة التي تدعمه
        });
    }
}

// بدء التشغيل
document.addEventListener('DOMContentLoaded', checkNotifications);